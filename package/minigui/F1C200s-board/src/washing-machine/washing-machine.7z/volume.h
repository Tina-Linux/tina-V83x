#ifndef __SMART_VOLUME_H__
#define __SMART_VOLUME_H__

int volume_set_volume(int volume);

int volume_get_volume(void);

int volume_init(void);

#endif
