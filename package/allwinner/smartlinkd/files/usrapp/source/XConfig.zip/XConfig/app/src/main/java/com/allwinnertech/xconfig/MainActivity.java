package com.allwinnertech.xconfig;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.allwinnertech.xconfig.Protocol.AES;
import com.allwinnertech.xconfig.Protocol.CRC8;
import com.allwinnertech.xconfig.UDPSockct.UDPMultiClient;
import com.allwinnertech.xconfig.UDPSockct.UDPMultiServer;
import com.allwinnertech.xconfig.UDPSockct.UDPServer;

import java.net.DatagramPacket;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    //UI控件
    private TextView ssidText;
    private TextView passwordText;
    private TextView ip;
    private Button start;
    private EditText information;

    //UDP通信
    private UDPServer udpServer;
    private UDPMultiClient udpClient;
    private UDPMultiServer udpMultiServer;

    //信息解析测试变量
    Information info;
    private ArrayList<Integer> cache;
    int running = 0;
    int SocketEnable = 0;
    int interval =200;
    final Handler serverHandler = new Handler() {
        public void handleMessage(Message msg){
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
            String time = simpleDateFormat.format(new java.util.Date());
            String str = msg.getData().getString("info");
            information.append(time+"||"+str+"\n");
        }
    };
    //static String LastPawd = "/0", LastSsid = "/0";
    @Override
        protected void onCreate(Bundle savedInstanceState) {

            //初始化WIFI管理类
            final WifiAdmin wifiAdmin = new WifiAdmin(this);
            wifiAdmin.openWifi();
            String ssidstring =wifiAdmin.getSSID();

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            //UI控件初始化
            ssidText = (TextView)findViewById(R.id.ssid);
            passwordText = (TextView)findViewById(R.id.password);
            ip = (TextView)findViewById(R.id.ip);
            start = (Button)findViewById(R.id.start);
            information = (EditText)findViewById(R.id.information);

            if(ssidstring != "<unknown ssid>"){
                ssidText.append(ssidstring.substring(1,ssidstring.length()-1));
                passwordText.setFocusable(true);
                passwordText.requestFocus();
            }
            ip.setText("1");
            udpMultiServer = new UDPMultiServer(this);
            udpServer = new UDPServer(this);
            start.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //初始化UDP通信的SERVER & CLIENT
                running = 1 - running;
                if (running > 0 && SocketEnable == 0) {
                    SocketEnable = 1;
                    udpClient = new UDPMultiClient();
                }
                try {
                    if (running > 0) {
                       // cache = new ArrayList();
                        String password = passwordText.getText().toString();//"sw4wifionly";
                        Log.e("password = ", password + ": length =" + password.length());
                        String ssid = ssidText.getText().toString();//"TES_TPLINK_TL_WDR5600#3232";//"林小竣";//"TES#07_NETGEAR";
                        String key = "1234567812345678";
                        //通过IP栏获取是否加密
                        String mark = ip.getText().toString();
                        String markmsg = "不需要加密";
                        if (mark.equals("1")) {
                            markmsg = "需要加密";
                        }
                        Message message1 = new Message();
                        Bundle bd = new Bundle();
                        message1 = serverHandler.obtainMessage();
                        message1.setData(bd);
                        bd.putString("info", password.length() + ssid.length() + 6 + "ge个原始数据&&" + markmsg);
                        serverHandler.sendMessage(message1);
                        info = new Information(wifiAdmin.getWifiManager(), password, ssid, key, mark);
                        Log.e("info", "info is Refresh");
                        Message message2 = new Message();
                        Bundle bd1 = new Bundle();
                        message2 = serverHandler.obtainMessage();
                        message2.setData(bd1);
                        bd1.putString("info", info.informationSize + "个加密数据");
                        serverHandler.sendMessage(message2);
                    }
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            while(running == 1){
                                final int LeadCode = 4;
                                int count = 1;
                                byte[]SendData = new byte[info.DataPackageSum * 3];
                                Log.e("info.DataPackageSum = ", info.DataPackageSum + "");
                                Log.e("info.length", + info.info.length + "");
                                for (int i = 0,j = 0;i < info.info.length; j = j + 3){
                                    if(i < LeadCode){
                                        SendData[j] = (byte)count;
                                        SendData[j + 1] = (byte) (info.info[i] & 0xff);
                                        byte[] crc = new byte[1];
                                        crc[0] =  (byte) (info.info[i] & 0xff);
                                        SendData[j + 2] = CRC8.CRC8(crc);
                                        i++;
                                    }else {
                                        SendData[j] = (byte)count;
                                        SendData[j + 1] =  (byte) (info.info[i] & 0xff);
                                        SendData[j + 2] = (byte) (info.info[i + 1] & 0xff);
                                        i = i + 2;
                                    }
                                    count ++;
                                }
                                /* for(int i =0; i < SendData.length; i++){
                                    Log.e("SendData","[" + i + "]" +SendData[i] + "");
                                }*/
                                    String[] UdpIpData = new String[3];
                                    String[] IP = new String[info.DataPackageSum];
                                    for (int j = 0; j < (SendData.length / 3); j++){
                                        for (int i = j * 3; i <  j * 3 + 3; i = i + 3) {
                                            UdpIpData[0] = String.valueOf(SendData[i] & 0xff);
                                            UdpIpData[1] = String.valueOf(SendData[i + 1] & 0xff);
                                            UdpIpData[2] = String.valueOf(SendData[i + 2] & 0xff);
                                        }
                                        IP[j] = "239." + UdpIpData[0] + "." + UdpIpData[1] + "." + UdpIpData[2];
                                    }
                                while(running == 1) {
                                    long current = System.currentTimeMillis();//当前时间
                                    byte []Data = new byte[1];
                                    for(int i = 0; i< 3; i++) {
                                        for (int j = 0; j < LeadCode; j++) {
                                            udpClient.send(Data, IP[j]);
                                            Log.e("UdpIp", "[" + j + "]" + IP[j]);
                                        }
                                    }
                                    for(int i = LeadCode; i < IP.length; i++) {
                                        udpClient.send(Data, IP[i]);
                                        if( (i % 5) == 0) {
                                            udpClient.send(Data, IP[0]);
                                            Log.e("UdpIp", "[" + i + "]" + IP[0]);
                                        }
                                        Log.e("UdpIp", "[" + i + "]" + IP[i]);
                                    }
                                    long now = System.currentTimeMillis();//获取系统当前时间
                                    Log.e("mark", (now - current) + "毫秒");
                                   /* Message message = new Message();
                                    Bundle bd = new Bundle();
                                    message = serverHandler.obtainMessage();
                                    message.setData(bd);
                                    bd.putString("info", (now - current) + "毫秒");
                                    serverHandler.sendMessage(message);*/
                                }
                                //break;
                            }
                        }
                    }).start();
                    //information.append("发送数据成功.\n");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        //Server端服务开始运行
        Thread serverThread = new Thread(new Runnable() {
           public void run() {
               while(!udpServer.getIsStop()){
                   DatagramPacket datagramPacket = udpServer.receive();
                   Log.e("rssss",datagramPacket.getData()[0]+"");
                   if (datagramPacket.getData()[0] ==info.randomNum){
                       running = 0;
                       Message message = new Message();
                       Bundle bd = new Bundle();
                       message = serverHandler.obtainMessage();
                       message.setData(bd);
                       bd.putString("info","设备连接成功+"+datagramPacket.getData()[0]);
                       serverHandler.sendMessage(message);
                       return ;
                   }
               }
           }
       });
       // serverThread.start();
}
    public static int fibonacci(int n){
        if(n <= 2){
            return 1;
        }else{
            return fibonacci(n-1) + fibonacci(n-2);
        }
    }
}
